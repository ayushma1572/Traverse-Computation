document.addEventListener("DOMContentLoaded", () => {
    // Get DOM elements
    const x1 = document.getElementById("knownX1");
    const y1 = document.getElementById("knownY1");
    const x2 = document.getElementById("knownX2");
    const y2 = document.getElementById("knownY2");
    const bearingCalcButton = document.getElementById("bearingCalc");
    const bearingResult = document.getElementById("bearingResult");

    const nAngle = document.getElementById("inputNumber");
    const anglesResult = document.getElementById("anglesResult");
    const submitAnglesButton = document.getElementById("submitAngles");
    const anglesContainer = document.getElementById("anglesContainer");

    const distancesSection = document.getElementById("distancesSection");
    const resultsSection = document.getElementById("resultsSection");

    // Calculate Bearing
    bearingCalcButton.addEventListener('click', () => {
        const x1Value = parseFloat(x1.value);
        const y1Value = parseFloat(y1.value);
        const x2Value = parseFloat(x2.value);
        const y2Value = parseFloat(y2.value);

        if (isNaN(x1Value) || isNaN(y1Value) || isNaN(x2Value) || isNaN(y2Value)) {
            bearingResult.textContent = "Please enter valid coordinates.";
            return;
        }

        const dx = x2Value - x1Value;
        const dy = y2Value - y1Value;
        let bearing = Math.atan2(dx, dy) * (180 / Math.PI);
        if (bearing < 0) bearing += 360;

        bearingResult.textContent = 'The bearing is: ' + bearing.toFixed(2) + '°';
    });

    // Generate Angle Inputs
    submitAnglesButton.addEventListener('click', () => {
        const numberofAngles = parseInt(nAngle.value, 10);
        anglesResult.textContent = "Enter each angle in decimal degrees.";
        anglesContainer.innerHTML = ""; // Clear previous inputs

        if (isNaN(numberofAngles) || numberofAngles < 3) {
            anglesResult.textContent = "Please enter a valid number greater than 2.";
            return;
        }

        for (let i = 0; i < numberofAngles; i++) {
            const inputBox = document.createElement("input");
            inputBox.type = "number";
            inputBox.placeholder = "Angle " + (i + 1);
            inputBox.className = "angleInputBox";
            anglesContainer.appendChild(inputBox);
            anglesContainer.appendChild(document.createElement("br"));
        }

        // Add Calculate Closing Error Button
        if (!document.getElementById('calculateButton')) {
            const calculateButton = document.createElement('button');
            calculateButton.textContent = 'Calculate Closing Error';
            calculateButton.id = 'calculateButton';
            anglesContainer.appendChild(calculateButton);
            calculateButton.addEventListener('click', storeAngles);
        }
    });

    function storeAngles() {
        const inputBoxes = document.querySelectorAll('.angleInputBox');
        let angles = [];

        inputBoxes.forEach(box => {
            const angleValue = parseFloat(box.value);
            if (!isNaN(angleValue)) angles.push(angleValue);
            else {
                alert('Please enter a valid number for all angles.');
                return;
            }
        });

        const observedAngle = angles.reduce((sum, angle) => sum + angle, 0);
        const actualAngle = (angles.length - 2) * 180;
        const correction = actualAngle - observedAngle;
        const disCorrection = correction / angles.length;

        anglesResult.innerHTML = `
            Total Observed Angle Sum: ${observedAngle.toFixed(2)}°<br>
            Total Actual Angle Sum: ${actualAngle.toFixed(2)}°<br>
            Error: ${correction.toFixed(2)}°<br><br>
            <strong>Corrected Angles:</strong><br>
        `;

        angles.forEach((angle, index) => {
            const correctedAngle = angle + disCorrection;
            anglesResult.innerHTML += `Angle ${index + 1}: ${correctedAngle.toFixed(3)}°<br>`;
        });

        // Add Calculate Bearings Button
        if (!document.getElementById('calculateBearingsButton')) {
            const calculateBearingsButton = document.createElement('button');
            calculateBearingsButton.textContent = 'Calculate Bearings';
            calculateBearingsButton.id = 'calculateBearingsButton';
            anglesResult.appendChild(calculateBearingsButton);
            calculateBearingsButton.addEventListener('click', calculateBearings);
        }
    }

    function calculateBearings() {
        const correctedAngles = document.querySelectorAll('.angleInputBox');
        const initialBearing = parseFloat(bearingResult.textContent.split(":")[1]);

        let currentBearing = initialBearing;
        resultsSection.innerHTML = '<strong>Calculated Bearings:</strong><br>';

        correctedAngles.forEach((angleBox, index) => {
            const angleValue = parseFloat(angleBox.value);
            if (isNaN(angleValue)) return;

            currentBearing = calculateNewBearing(currentBearing, angleValue);

            resultsSection.innerHTML += `Bearing ${index + 1}: ${currentBearing.toFixed(2)}°<br>`;
        });

        // Add Enter Distance Button
        if (!document.getElementById('enterDistanceButton')) {
            const enterDistanceButton = document.createElement('button');
            enterDistanceButton.textContent = 'Enter Distance';
            enterDistanceButton.id = 'enterDistanceButton';
            resultsSection.appendChild(enterDistanceButton);
            enterDistanceButton.addEventListener('click', enterDistance);
        }
    }

    function calculateNewBearing(previousBearing, includedAngle) {
        if (previousBearing < 180) {
            let newBearing = previousBearing + 180 + includedAngle;
            if (newBearing >= 360) newBearing -= 360;
            return newBearing;
        } else {
            let newBearing = previousBearing - 180 + includedAngle;
            if (newBearing >= 360) newBearing -= 360;
            return newBearing;
        }
    }

    function enterDistance() {
        const bearingBoxes = document.querySelectorAll('.angleInputBox');

        const oldDistancesContainer = document.getElementById('distancesContainer');
        if (oldDistancesContainer) oldDistancesContainer.remove();

        const distancesContainer = document.createElement('div');
        distancesContainer.id = 'distancesContainer';
        distancesSection.appendChild(distancesContainer);

        distancesContainer.innerHTML = '<strong>Enter Distances:</strong><br>';

        for (let i = 1; i < bearingBoxes.length; i++) {
            const distanceInputBox = document.createElement("input");
            distanceInputBox.type = "number";
            distanceInputBox.placeholder = "Distance " + i;
            distanceInputBox.className = "distanceInputBox";
            distancesContainer.appendChild(distanceInputBox);
            distancesContainer.appendChild(document.createElement("br"));
        }

        // Add Calculate Latitude and Departure Button
        if (!document.getElementById('calculateLatDepButton')) {
            const calculateLatDepButton = document.createElement('button');
            calculateLatDepButton.textContent = 'Calculate Latitude and Departure';
            calculateLatDepButton.id = 'calculateLatDepButton';
            distancesContainer.appendChild(calculateLatDepButton);
            calculateLatDepButton.addEventListener('click', calculateLatitudeDeparture);
        }
    }

function calculateLatitudeDeparture() {
    const bearingBoxes = document.querySelectorAll('.angleInputBox');
    const distanceInputs = document.querySelectorAll('.distanceInputBox');

    const oldResultsContainer = document.getElementById('resultsContainer');
    if (oldResultsContainer) oldResultsContainer.remove();

    const resultsContainer = document.createElement('div');
    resultsContainer.id = 'resultsContainer';
    resultsSection.appendChild(resultsContainer);

    let totalLatitude = 0;
    let totalDeparture = 0;

    distanceInputs.forEach((inputBox, index) => {
        const distance = parseFloat(inputBox.value);
        if (isNaN(distance)) {
            alert('Please enter valid distances.');
            return;
        }

        // Make sure we use the correct bearing for the distance
        const bearing = parseFloat(bearingBoxes[index + 1].value.split(":")[1].trim());

        if (isNaN(bearing)) {
            alert('Please enter valid bearings.');
            return;
        }

        const bearingRad = bearing * (Math.PI / 180); // Convert bearing to radians
        const latitude = distance * Math.sin(bearingRad);
        const departure = distance * Math.cos(bearingRad);

        totalLatitude += latitude;
        totalDeparture += departure;

        resultsContainer.innerHTML += `Distance ${index + 1}: ${distance.toFixed(2)}m<br>`;
        resultsContainer.innerHTML += `Bearing ${index + 1}: ${bearing.toFixed(2)}°<br>`;
        resultsContainer.innerHTML += `Latitude: ${latitude.toFixed(2)}m<br>`;
        resultsContainer.innerHTML += `Departure: ${departure.toFixed(2)}m<br><br>`;
    });

    resultsContainer.innerHTML += `<strong>Total Latitude:</strong> ${totalLatitude.toFixed(2)}m<br>`;
    resultsContainer.innerHTML += `<strong>Total Departure:</strong> ${totalDeparture.toFixed(2)}m<br>`;
}

});
