const x1 = document.getElementById("myknownX1");
const y1 = document.getElementById("myknownY1");
const x2 = document.getElementById("myknownX2");
const y2 = document.getElementById("myknownY2");
const bearingButton = document.getElementById("bearing");
const bearingResult = document.getElementById("bearingresult");

const nAngle = document.getElementById("myinputnumber1");
const nResult = document.getElementById("nresult");
const submitButton = document.getElementById("submitbutton1");
const inputboxAngles = document.getElementById("inputboxAngles");

function getBearing() {
    const x1Value = parseFloat(x1.value);
    const y1Value = parseFloat(y1.value);
    const x2Value = parseFloat(x2.value);
    const y2Value = parseFloat(y2.value);
    if (isNaN(x1Value) || isNaN(y1Value) || isNaN(x2Value) || isNaN(y2Value)) {
        bearingResult.textContent = "Please enter valid coordinates for both stations.";
        return;
    }
    const dx = x2Value - x1Value;
    const dy = y2Value - y1Value;
    let bearing = Math.atan2(dx, dy) * (180 / Math.PI);
    if (bearing < 0) {
        bearing += 360;
    }
    bearingResult.textContent = 'The bearing of line 12 is: ' + bearing.toFixed(2) + '°';
}
bearingButton.addEventListener('click', getBearing);

function getnAngles() {
    const numberOfAngles = parseInt(nAngle.value, 10);
    nResult.textContent = "Enter each Angle in decimal degrees (Angles in degree minute seconds cannot be processed!!)";
    inputboxAngles.innerHTML = "";

    if (isNaN(numberOfAngles) || numberOfAngles <= 0) {
        nResult.textContent = "Please enter a valid number greater than 0.";
        return;
    } else if (numberOfAngles < 3) {
        nResult.textContent = "A minimum of three angles is required for a closed traverse.";
        return;
    }

    for (let i = 0; i < numberOfAngles; i++) {
        const inputBox = document.createElement("input");
        inputBox.type = "number";
        inputBox.placeholder = "Enter Angle " + (i + 1) + ":";
        inputBox.className = "angleInputBox";
        inputboxAngles.appendChild(inputBox);
    }

    if (!document.getElementById('calculateButton')) {
        const calculateButton = document.createElement('button');
        calculateButton.textContent = 'Calculate Closing Error';
        calculateButton.id = 'calculateButton';
        inputboxAngles.appendChild(calculateButton);
        calculateButton.addEventListener('click', storeAngle);
    }
}

function storeAngle() {
    const inputBoxes = document.querySelectorAll('.angleInputBox');
    var angles = [];

    for (let i = 0; i < inputBoxes.length; i++) {
        const inputBox = inputBoxes[i];
        const angleValue = parseFloat(inputBox.value);

        if (!isNaN(angleValue)) {
            angles.push(angleValue);
        } else {
            alert('Please enter a valid number for Angle ' + (i + 1) + ":");
            return;
        }
    }

    var observedAngle = 0;
    for (let i = 0; i < angles.length; i++) {
        observedAngle += angles[i];
    }

    const actualAngle = (angles.length + 2) * 180;
    const correction = actualAngle - observedAngle;
    var disCorrection = correction / angles.length;

    inputboxAngles.innerHTML += "<br>";
    inputboxAngles.innerHTML += "<br>";
    inputboxAngles.innerHTML += "Total Observed Angle Sum: " + observedAngle.toFixed(2) + "°";
    inputboxAngles.innerHTML += "<br>";
    inputboxAngles.innerHTML += "Total Actual Angle Sum: " + actualAngle.toFixed(2) + "°";
    inputboxAngles.innerHTML += "<br>";
    inputboxAngles.innerHTML += "Error: " + correction.toFixed(2) + "°";
    inputboxAngles.innerHTML += "<br>";
    inputboxAngles.innerHTML += "<br>";
    inputboxAngles.innerHTML += '<strong>Corrected Angles:</strong>';
    inputboxAngles.innerHTML += "<br>";

    for (let i = 0; i < angles.length; i++) {
        const correctedAngle = angles[i] + disCorrection;
        const correctedInputBox = document.createElement("input");
        correctedInputBox.type = "text";
        correctedInputBox.value = 'Angle ' + (i + 1) + ":" + correctedAngle.toFixed(3) + "°";
        correctedInputBox.disabled = true;
        correctedInputBox.className = "correctedAngleBox";
        inputboxAngles.appendChild(correctedInputBox);
        inputboxAngles.appendChild(document.createElement("br"));
    }

    // Button to Calculate Bearings
    const calculateBearingsButton = document.createElement('button');
    calculateBearingsButton.textContent = 'Calculate Bearings';
    calculateBearingsButton.id = 'calculateBearingsButton';
    inputboxAngles.appendChild(calculateBearingsButton);
    calculateBearingsButton.addEventListener('click', calculateBearings);
}

function calculateBearings() {
    const correctedAngles = document.querySelectorAll('.correctedAngleBox');
    const initialBearing = parseFloat(bearingResult.textContent.split(":")[1]);
    let currentBearing = initialBearing;

    const bearingsContainer = document.createElement('div');
    bearingsContainer.id = 'bearingsContainer';
    inputboxAngles.appendChild(bearingsContainer);

    const bearings = [];
    for (let i = 0; i < correctedAngles.length; i++) {
        const angleValue = parseFloat(correctedAngles[i].value.split(":")[1]);
        currentBearing += angleValue;
        if (currentBearing >= 360) {
            currentBearing -= 360;
        }
        bearings.push(currentBearing);
    }

    let bearingsOutput = '<strong>Calculated Bearings:</strong><br>';
    for (let i = 0; i < bearings.length; i++) {
        bearingsOutput += 'Bearing ' + (i + 1) + ': ' + bearings[i].toFixed(2) + '°<br>';
    }
    bearingsContainer.innerHTML = bearingsOutput;

    // Add input fields for distances
    const distancesContainer = document.getElementById('distancesContainer');
    distancesContainer.innerHTML = '<h2>Enter Distances</h2>';
    for (let i = 0; i < bearings.length; i++) {
        const distanceInput = document.createElement('input');
        distanceInput.type = 'number';
        distanceInput.placeholder = 'Enter Distance ' + (i + 1) + ':';
        distanceInput.className = 'distanceInputBox';
        distancesContainer.appendChild(distanceInput);
        distancesContainer.appendChild(document.createElement('br'));
    }

    const calculateDistancesButton = document.createElement('button');
    calculateDistancesButton.textContent = 'Calculate Latitude and Departure';
    calculateDistancesButton.id = 'calculateDistancesButton';
    distancesContainer.appendChild(calculateDistancesButton);
    calculateDistancesButton.addEventListener('click', calculateLatitudeDeparture);
}

function calculateLatitudeDeparture() {
    const distances = document.querySelectorAll('.distanceInputBox');
    const bearings = document.querySelectorAll('.correctedAngleBox');
    
    let totalLatitude = 0;
    let totalDeparture = 0;
    const resultsContainer = document.getElementById('resultsContainer');
    resultsContainer.innerHTML = '<h2>Calculated Latitude and Departure:</h2>';
    
    for (let i = 0; i < distances.length; i++) {
        const distance = parseFloat(distances[i].value);
        const bearing = parseFloat(bearings[i].value.split(":")[1]);
        const bearingRad = bearing * (Math.PI / 180);
        const latitude = distance * Math.sin(bearingRad);
        const departure = distance * Math.cos(bearingRad);
        
        totalLatitude += latitude;
        totalDeparture += departure;
        
        resultsContainer.innerHTML += 'Line ' + (i + 1) + ': Lat=' + latitude.toFixed(4) + ', Dep=' + departure.toFixed(4) + '<br>';
    }

    resultsContainer.innerHTML += '<strong>Total:</strong> Lat=' + totalLatitude.toFixed(4) + ', Dep=' + totalDeparture.toFixed(4);

    // Apply Bowditch Correction
    applyBowditchCorrection(totalLatitude, totalDeparture, distances.length);
}

function applyBowditchCorrection(totalLatitude, totalDeparture, numSides) {
    const resultsContainer = document.getElementById('resultsContainer');
    const closingError = Math.sqrt(Math.pow(totalLatitude, 2) + Math.pow(totalDeparture, 2));
    const linearAccuracy = closingError / numSides;

    resultsContainer.innerHTML += '<h2>Apply Bowditch Correction</h2>';
    resultsContainer.innerHTML += 'Closing Error: ' + closingError.toFixed(4) + '<br>';
    resultsContainer.innerHTML += 'Linear Accuracy: ' + linearAccuracy.toFixed(4) + '<br>';
}

submitButton.addEventListener('click', getnAngles);
