document.getElementById('homeBtn').addEventListener('click', function() {
    showPage('homePage');
});

document.getElementById('anticlockwiseBtn').addEventListener('click', function() {
});

document.getElementById('clockwiseBtn').addEventListener('click', function() {

});


function showPage(pageId) {
    let pages = document.querySelectorAll('.page');
    pages.forEach(page => page.style.display = 'none');
    document.getElementById(pageId).style.display = 'block';
}
